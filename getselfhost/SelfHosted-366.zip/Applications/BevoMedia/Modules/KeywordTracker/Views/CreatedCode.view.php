<h3>
	Destination URL:
</h3>
<p><textarea class="code" rows="1" readonly="readonly" wrap="off"><?php print $this->codeRow->destinationUrl; ?></textarea></p>
<h3>
	Offer URL:
</h3>
<p><textarea class="code" rows="1" readonly="readonly" wrap="off"><?php print $this->codeRow->offerUrl; ?></textarea></p>
<h3>
	Redirect Code:
</h3>
<p><textarea class="code" rows="3" readonly="readonly" wrap="off"><?php print $this->codeRow->redirectCode; ?></textarea></p>
<h3>
	Landing Page Code:
</h3>
<p><textarea class="code" rows="4" readonly="readonly" wrap="off"><?php print $this->codeRow->landingPageCode; ?></textarea></p>


<br/><br/>