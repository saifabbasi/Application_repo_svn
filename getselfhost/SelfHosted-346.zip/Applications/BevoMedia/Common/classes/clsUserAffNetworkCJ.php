<?php

class UserAffNetworkCJ extends DBObject {

	function __construct() {
		parent::__construct('ADPALACE_USER_AFF_NETWORK_CJ', 'ID', array('UserNetworkID', 'DevKey'));
	}
	
	function GetDetailsByID($intInID) {
		$strSQL = 'SELECT ID, DevKey FROM ADPALACE_USER_AFF_NETWORK_CJ WHERE (UserNetworkID = ' . $intInID . ')';
		$this->Select($strSQL);
		
		$arrRow = $this->GetRow();
		$this->ID = $arrRow['ID'];
		$this->DevKey = $arrRow['DevKey'];
	}

}

?>