<?php

class NetworkSubIDs extends DBObject {

	function __construct() {
		parent::__construct('ADPALACE_USER_AFF_NETWORK_SUBID', 'ID', array('USERID', 'NETWORK_ID', 'STAT_DATE', 'OFFER_ID', 'SUB_ID', 'Clicks', 'Conversions', 'Revenue'));
	}
	
	function GetListByUserID($intInUserID, $intInNetworkID, $inStartDate = '', $inEndDate = '') {
		if (!is_numeric($intInUserID)) {
			return false;
		}
		
		if (!is_numeric($intInNetworkID)) {
			return false;
		}
		
		if (!empty($inStartDate)) {
			$strWhere = 'ADPALACE_USER_AFF_NETWORK_SUBID.Stat_Date >= \'' . date('Y-m-d', strtotime($inStartDate)) . '\'';
			
			if (!empty($inEndDate)) {
				$strWhere .= ' AND ADPALACE_USER_AFF_NETWORK_SUBID.Stat_Date <= \'' . date('Y-m-d', strtotime($inEndDate)) . '\'';
			}
			
			if (strlen($strWhere) > 1) {
				$strWhere = ' AND (' . $strWhere . ') ';
			}
		}
		
		$strSQL = 'SELECT ADPALACE_USER_AFF_NETWORK_SUBID.OFFER_ID, SUM(Clicks) AS ClickSum, SUM(Conversions) AS ConvSum, SUM(Revenue) AS NetRevenue, ADPALACE_AFF_NETWORK.Title AS NetworkTitle, ADPALACE_OFFERS.Title AS OfferTitle
					FROM (ADPALACE_USER_AFF_NETWORK_SUBID LEFT JOIN ADPALACE_AFF_NETWORK ON ADPALACE_USER_AFF_NETWORK_SUBID.NETWORK_ID = ADPALACE_AFF_NETWORK.ID)
					LEFT JOIN ADPALACE_OFFERS ON ADPALACE_USER_AFF_NETWORK_SUBID.OFFER_ID = ADPALACE_OFFERS.OFFER_ID
						AND ADPALACE_USER_AFF_NETWORK_SUBID.NETWORK_ID = ADPALACE_OFFERS.NETWORK_ID
					WHERE (ADPALACE_USER_AFF_NETWORK_SUBID.USERID = ' . $intInUserID . ' AND ADPALACE_USER_AFF_NETWORK_SUBID.NETWORK_ID = ' . $intInNetworkID . ') ';
		$strSQL .= $strWhere;
		$strSQL .= ' GROUP BY OFFER_ID, NetworkTitle, OfferTitle';
		
		$this->Select($strSQL);
	}

}

?>