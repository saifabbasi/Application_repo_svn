	<div id="pageinfo" class="ads"><p>Let BeVo Media optimize ad space on your web site.  Using a proprietary algorithm, BeVo will analyze all of the ad networks that you belong to in order to determine the best ad to display for each impression.  The BeVo AdOptimizer will maximize profits on your available ad space automatically. </p></div>

	<div class="clear"></div>

	<div id="vidbox" class="ads">
		<div id="movie">
			<object	type="application/x-shockwave-flash" data="<?=$this->{'System/BaseURL'};?>Themes/<?=$this->{'Application/Theme'};?>/ads.swf" width="305" height="268">
				<param name="movie" value="<?=$this->{'System/BaseURL'};?>Themes/<?=$this->{'Application/Theme'};?>/ads.swf" />
			</object>
		</div>
	</div>
