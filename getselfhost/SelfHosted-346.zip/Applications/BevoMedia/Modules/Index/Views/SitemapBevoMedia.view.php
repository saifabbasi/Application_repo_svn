	
	<div id="pageinfo" class="sub">
		<h2>Sitemap</h2>
	</div>
	<div class="clear"></div>
	
	<div class="content"> 
 
	<h3>BeVo Media Navigation</h3>
	<ul id="sitemapmenu">
		<li><a class="home" href="<?=$this->{'System/BaseURL'};?><?=$this->{'Application/Theme'};?>/Index/Index.html">BeVo Media Homepage</a></li>
		<li><a class="networks" href="<?=$this->{'System/BaseURL'};?><?=$this->{'Application/Theme'};?>/Index/SitemapBevoMedia.html?p=networks">Consolidate your Networks</a></li>
		<li><a class="offers" href="<?=$this->{'System/BaseURL'};?><?=$this->{'Application/Theme'};?>/Index/SitemapBevoMedia.html?p=offers">Retrieve your Offers</a></li>
		<li><a class="ads" href="<?=$this->{'System/BaseURL'};?><?=$this->{'Application/Theme'};?>/Index/SitemapBevoMedia.html?p=ads">Optimize your Ads</a></li>
		<li><a class="ppc" href="<?=$this->{'System/BaseURL'};?><?=$this->{'Application/Theme'};?>/Index/SitemapBevoMedia.html?p=ppc">Manage your PPC Platforms</a></li>
		<li><a class="keywords" href="<?=$this->{'System/BaseURL'};?><?=$this->{'Application/Theme'};?>/Index/SitemapBevoMedia.html?p=keywords">Track your Keywords</a></li>
		<li><a class="analytics" href="<?=$this->{'System/BaseURL'};?><?=$this->{'Application/Theme'};?>/Index/SitemapBevoMedia.html?p=analytics">Examine your Analytics</a></li>
		<li><a class="classroom" href="<?=$this->{'System/BaseURL'};?><?=$this->{'Application/Theme'};?>/Index/SitemapBevoMedia.html?p=classroom">Learn in the Classroom</a></li>
		<li><a class="signup" href="<?=$this->{'System/BaseURL'};?><?=$this->{'Application/Theme'};?>/User/Register.html">Signup for a BeVo Media Account</a></li>
	</ul>	


	<h3>Additional Publisher Affiliate Network Tools</h3>
	<ul>
		<li><a href="<?=$this->{'System/BaseURL'};?><?=$this->{'Application/Theme'};?>/Index/seo.htm">Search Engine Optimization Help</a></li>
		<li><a href="<?=$this->{'System/BaseURL'};?><?=$this->{'Application/Theme'};?>/Index/programming.htm">Programming Help</a></li>
	</ul>
		
	<h3>Bevo Media Information </h3> 
	<ul>
		<li><a href="<?=$this->{'System/BaseURL'};?><?=$this->{'Application/Theme'};?>/Index/PrivacyPolicyBevoMedia.html">Privacy Policy</a></li>
		<li><a href="<?=$this->{'System/BaseURL'};?><?=$this->{'Application/Theme'};?>/Index/TermsOfServiceBevoMedia.html">Terms of Service</a></li>
		<li><a href="<?=$this->{'System/BaseURL'};?><?=$this->{'Application/Theme'};?>/Index/AboutBevoMedia.html">About BeVo Media</a></li>
		<li><a href="<?=$this->{'System/BaseURL'};?><?=$this->{'Application/Theme'};?>/Index/FaqsBevoMedia.html">FAQs</a></li>
		<li><a href="<?=$this->{'System/BaseURL'};?><?=$this->{'Application/Theme'};?>/Index/CareersBevoMedia.html">Careers</a></li>
		<li><a href="<?=$this->{'System/BaseURL'};?><?=$this->{'Application/Theme'};?>/Index/PressBevoMedia.html">Press</a></li>
		<li><a href="<?=$this->{'System/BaseURL'};?><?=$this->{'Application/Theme'};?>/Index/InvestorsBevoMedia.html">Investors</a></li>
	</ul> 
</div> 