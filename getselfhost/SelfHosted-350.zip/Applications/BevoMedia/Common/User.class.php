<?php

/**
 * User Class
 */

/**
 * User Class
 * 
 * User Class
 * @category	BevoMedia
 * @package 	Application
 * @subpackage 	Common
 * @copyright 	Copyright (c) 2009 RCS
 * @author 		RCS
 * @version 	0.1
 */

Class User {
	
	/**
	 * @var Zend_Db_Adapter_Abstract $_db
	 */
	Protected $_db = false;
	
	/**
	 * @var Integer $id
	 */
	Public $id;
	
	/**
	 * @var String $email
	 */
	Public $email;
	
	/**
	 * @var String $password
	 */
	Public $password;
	
	/**
	 * @var Integer $enabled
	 */
	Public $enabled;
	
	/**
	 * @var String $created
	 */
	Public $created;
	
	/**
	 * @var Integer $deleted
	 */
	Public $deleted;
	
	
	/**
	 * @var String $membershipType
	 */
	Public $membershipType;

	/**
	 * @var integer
	 */
	Public $apiCalls;
	
	
	Public $lastNetworkUpdate;
	Public $lastPPCUpdate;
	
	
	/**
	 * @var String $firstName
	 */
	Public $firstName;
	
	/**
	 * @var String $lastName
	 */
	Public $lastName;
	
	/**
	 * @var String $companyName
	 */
	Public $companyName;
	
	/**
	 * @var String $address
	 */
	Public $address;
	
	/**
	 * @var String $city
	 */
	Public $city;
	
	/**
	 * @var String $state
	 */
	Public $state;
	
	/**
	 * @var String $zip
	 */
	Public $zip;
	
	/**
	 * @var String $country
	 */
	Public $country;
	
	/**
	 * @var String $phone
	 */
	Public $phone;
	
	/**
	 * @var String $website
	 */
	Public $website;
	
	/**
	 * @var String $messenger
	 */
	Public $messenger;
	
	/**
	 * @var String $messengerHandle
	 */
	Public $messengerHandle;
	
	/**
	 * @var String $marketingMethod
	 */
	Public $marketingMethod;
	
	/**
	 * @var String $marketingMethodOther
	 */
	Public $marketingMethodOther;
	
	/**
	 * @var String $howHeard
	 */
	Public $howHeard;
	
	/**
	 * @var String $comments
	 */
	Public $comments;
	
	/**
	 * @var Mixed $Stats
	 */
	Public $Stats;
	
	
	/**
	 * @var Mixed $lastLogin
	 */
	Public $lastLogin;
	
	
	/**
	 * @var String $Timezone
	 */
	Public $Timezone;
	
	private $apiKey = false;
	
	/**
	 * Constructor
	 *
	 * @param Integer $ID
	 */
	Public Function __construct($ID = false)
	{
		if(class_exists('Zend_Registry'))
		{
			$this->_db = Zend_Registry::get('Instance/DatabaseObj');
		}else{
			$IncludePaths = array(
			    realpath(ABSPATH .'Externals'),
			    '.',
			);
			set_include_path(implode(PATH_SEPARATOR, $IncludePaths));
			
			require_once ABSPATH . 'Externals/Zend/Db.php';
			$config = array(
			    'host'     => ABSDBHOST,
			    'username' => ABSDBUSER,
			    'password' => ABSDBPASS,
			    'dbname'   => ABSDBNAME,
			);
			
			$this->_db = Zend_Db::factory('PDO_MYSQL', $config);
			$this->_db->setFetchMode(Zend_Db::FETCH_OBJ);
		}

		if($ID !== false)
		{
			$this->id = $ID;
			$this->getInfo();
		}		
	}
	
	/**
	 * Unsets the User parameter from $_SESSION effectively logging this User out.
	 */
	Public Function Logout()
	{
		unset($_SESSION['User']);
	}
	
	/**
	 * Populates this $Stats with a new User_Stats class using this $ID.
	 * @see User_Stats
	 */
	Public Function LoadStats()
	{
		$this->Stats = new User_Stats($this->id);
	}
	
	/**
	 * Returns '1' if the account for this use is self hosted and '0' if is a self hosted install
	 * or if the account is not self hosted
	 * @return string
	 */
	Public Function IsSelfHosted()
	{
		return '1';
	}
	
	/**
	 * Removes api calls from the user
	 */
	Public Function subtractApiCalls($amount)
	{
		$this->getInfo($this->id);
		
		$Data = array('apiCalls'=>$this->apiCalls-$amount);
		$this->_db->update('bevomedia_user', $Data, 'id = ' . $this->id);
	}
	
	Public Function setLastNetworkUpdate($at)
	{
		$Data = array('lastNetworkUpdate'=>$at);
		$this->_db->update('bevomedia_user', $Data, 'id = ' . $this->id);
		$this->lastNetworkUpdate = date('c', strtotime($at));
	}
	Public Function setLastPPCUpdate($at)
	{
		$Data = array('lastPPCUpdate'=>$at);
		$this->_db->update('bevomedia_user', $Data, 'id = ' . $this->id);
		$this->lastPPCUpdate = date('c', strtotime($at));
	}
	
	
	Public Function setApiCalls($amount)
	{
		$this->getInfo($this->id);
		
		$Data = array('apiCalls'=>$amount);
		$this->_db->update('bevomedia_user', $Data, 'id = ' . $this->id);
		$this->apiCalls = $amount;
	}
	Public Function getApiKey() {
		if($this->apiKey)
			return $this->apiKey;
		$this->getInfo($this->id);
		require_once(PATH.'PhoneHome.class.php');
		$ph = new PhoneHome();
		if($ph->bevo_auth($this))
		{
			$this->apiKey = $ph->apiKey;
		}
		return $this->apiKey;
	}
	/**
	 * Returns an array of rows from the Accounts_Adwords table that have a valid Username and Password.
	 *
	 * @return Array
	 */
	Public Function getDailyAccountsAdwords()
	{
		$AcctAdwords = new Accounts_Adwords($this->id);
		return $AcctAdwords->GetInstalledAccounts();
	}
	
	/**
	 * Returns array of all rows from the Accounts_Analytics table for the User matching this $ID.
	 *
	 * @return Array
	 */
	Public Function getAllAccountsAnalytics()
	{
		$AcctAnalytics = new Accounts_Analytics($this->id);
		return $AcctAnalytics->GetAllAccounts();
	}
	
	/**
	 * Returns array of all rows from the Accounts_Adwords table for the User matching this $ID.
	 *
	 * @return Array
	 */
	Public Function getAllAccountsAdwords()
	{
		$AcctAdwords = new Accounts_Adwords($this->id);
		return $AcctAdwords->GetAllAccounts();
	}
	
	/**
	 * Returns array of all rows from the Accounts_Yahoo table for the User matching this $ID.
	 *
	 * @return Array
	 */
	Public Function getAllAccountsYahoo()
	{
		$AcctYahoo = new Accounts_Yahoo($this->id);
		return $AcctYahoo->GetAllAccounts();
	}
	
	/**
	 * Returns array of all rows from the Accounts_MSN table for the User matching this $ID.
	 *
	 * @return Array
	 */
	Public Function getAllAccountsMSN()
	{
		$AcctMSN = new Accounts_MSNAdCenter($this->id);
		return $AcctMSN->GetAllAccounts();
	}
	
	/**
	 * Return array of all rows from all three PPC Providers for all users.
	 *
	 * @return Array
	 */
	Public Function getAllAccounts()
	{
		$Output = array();
		foreach($this->GetAllAccountsAdwords() as $Adwords)
			$Output[] = $Adwords;
		foreach($this->GetAllAccountsYahoo() as $Yahoo)
			$Output[] = $Yahoo;
		foreach($this->GetAllAccountsMSN() as $MSN)
			$Output[] = $MSN;
			
		return $Output;
	}

	
	/**
	 * Populates the object with information from the database.
	 * 
	 * @param Integer $User_ID
	 * 
	 * @return User
	 */
	Public Function getInfo($User_ID = false)
	{
		if(!isset($this->id) && $User_ID == false)
		{
			return false;
		}
			
		if($User_ID == false)
			$User_ID = $this->id;
		
		$Sql = 'SELECT bevomedia_user.*, bevomedia_user_info.*, bevomedia_user_timezone.timezone as timezone FROM bevomedia_user LEFT JOIN bevomedia_user_info USING (id) LEFT JOIN bevomedia_user_timezone ON (bevomedia_user_timezone.user__id = bevomedia_user.id) WHERE bevomedia_user.id = ?';
		$Result = $this->_db->fetchRow($Sql, $User_ID);
		if($Result)
		{
			foreach($Result as $Key=>$Value)
			{
				$this->set($Key, $Value);
			}
			if($User_ID)
				$this->id = $User_ID;
		}else{
			return false;
		}
		return $this;
	}
	
	/**
	 * Return the concatenation of this $FirstName and this $LastName separated by a single space.
	 *
	 * @return String
	 */
	Public Function getUserName()
	{
		return $this->firstName . ' ' . $this->lastName;
	}
	
	/**
	 * Return the ID of a User matching the specified $Email.
	 * Return false otherwise.
	 * 
	 * @param String $Email
	 * @return Mixed
	 */
	Public Function getIdUsingEmail($Email)
	{
		$Result = $this->_db->fetchRow('SELECT * FROM bevomedia_user WHERE email = ?', $Email);
		if(!$Result || !sizeOf($Result))
			return false;
		return $Result->id;
	}
	
	/**
	 * Return true if the specified $Email exists within the User table.
	 *
	 * @param String $Email
	 * @return Boolean
	 */
	Public Function emailExists($Email)
	{
		$Result = $this->_db->fetchRow('SELECT * FROM bevomedia_user WHERE email = ?', $Email);
		if(sizeOf($Result) == 0 || !$Result)
			return false;
		else
			return true;
	}
	
	/**
	 * Inserts a new row into the table using the values provided by $Data and returns the table insert ID.
	 *
	 * @todo				Add sample code.
	 * 
	 * @param Array $Data	The values to be inserted into the table.
	 * @return Integer		The id of the inserted row.
	 */
	Public Function Insert($Data)
	{
		$Insert = array();
		$Insert['Email'] = $Data['Email'];
		$Insert['Password'] = $Data['Password'];
		
		
		$Sql = "SELECT value FROM bevomedia_settings WHERE name = 'Auto_Accept_New_Applicants'";
		$Auto_Accept_New_Applicants = $this->_db->fetchRow($Sql);
		$Auto_Accept_New_Applicants = intval($Auto_Accept_New_Applicants->value);
		
		if($this->EmailExists($Insert['Email']) == false)
		{
			foreach($Insert as $Key=>$Value)
				$Insert[$Key] = $this->_db->quote($Value);
			
			$Sql = "Insert INTO bevomedia_user (email, password) VALUES ($Insert[Email], md5($Insert[Password]))";
			$this->_db->exec($Sql);
			$this->id = $this->_db->lastInsertId();
		}else{
			echo 'ERROR EMAIL ALREADY TAKEN';
			return 0;
		}
		
		$this->InsertInfo($Data, $this->id);
		
		$Timezone = $Data['Timezone'];
		$this->InsertTimezone($Timezone, $this->id);
		if ($Auto_Accept_New_Applicants==1)
		{
			$this->EnableUser($this->id);
		}
		
		$this->GetInfo();
		
		return $this->id;
	}
	
	/**
	 * Updates the UserInfo table setting values within $Data where the row ID equals this $ID.
	 *
	 * @param Array $Data
	 */
	Public Function Update($Data)
	{
		$Timezone = $Data['Timezone'];
		unset($Data['Timezone']);
		$this->_db->update('bevomedia_user_info', $Data, 'id = ' . $this->id);
		$this->UpdateTimezone($Timezone, $this->id);
		$this->GetInfo();
	}
	
	/**
	 * Updates the User and UserInfo table setting rows to Deleted status where the row ID matches the specified $ID.
	 *
	 * @param Integer $ID
	 */
	Public Function DeleteUser($ID)
	{
		$Data = array('deleted'=>1);
		$this->_db->update('bevomedia_user', $Data, 'ID = ' . $ID);
		$this->_db->update('bevomedia_user_info', $Data, 'ID = ' . $ID);
	}

	Public Function UpdateMembershipType($MembershipType, $ID = NULL)
	{
		if($ID == NULL)
		{
			$ID = $this->id;
		}
		$Data = array('membershipType'=>$MembershipType);
		$this->_db->update('bevomedia_user', $Data, 'id = ' . $ID);
	}
	
	
	/**
	 * Permanently removes rows from User and UserInfo where the row ID matches this $ID.
	 */
	Public Function PermanentDelete()
	{
		$this->_db->delete('bevomedia_user', 'ID = ' . $this->id);
		$this->_db->delete('bevomedia_user_info', 'ID = ' . $this->id);
	}
	
	/**
	 * Updates the User and UserInfo table unsetting the Deleted status from rows where the row ID matches the specified $ID.
	 *
	 * @param Integer $ID
	 */
	Public Function RestoreUser($ID)
	{
		$Data = array('deleted'=>0);
		$this->_db->update('bevomedia_user', $Data, 'id = ' . $ID);
		$this->_db->update('bevomedia_user_info', $Data, 'id = ' . $ID);
	}
	
	/**
	 * Returns the amount of notes that this user has been given by Admins.
	 * @see Admin
	 * @see User_Notes::Insert()
	 *
	 * @return Index
	 */
	Public Function getNoteCount()
	{
		$Notes = new User_Notes();
		$Notes = $Notes->GetAllNotes($this->id);
		return sizeOf($Notes);
	}
	
	/**
	 * Returns an array of User objects for all rows within the User table.
	 * 
	 * @see User
	 * @return Array
	 */
	Public Function getAllUsers()
	{
		$Output = array();
		$Users = $this->_db->fetchAll('SELECT * FROM bevomedia_user');
		foreach($Users as $User)
			$Output[] = new User($User->id);
			
		return $Output;
	}
	
	/**
	 * Returns an array of User objects for all rows within the User table where the specified $Search matches any of the following properties: <br/>
	 * FirstName, LastName, Email, Comments, Website, MessengerHandle
	 *
	 * @param String $Search
	 * @return Array
	 */
	Public Function searchUsers($Search = false)
	{
		$Output = array();
		if($Search === false)
			return $Output;
			
		$Users = $this->_db->fetchAll("SELECT bevomedia_user.id as id FROM bevomedia_user LEFT JOIN bevomedia_user_info ON bevomedia_user_info.id = bevomedia_user.id
					WHERE (	firstName LIKE '%$Search%' OR lastName LIKE '%$Search%' OR 
							email LIKE '%$Search%' OR comments LIKE '%$Search%' OR 
							website LIKE '%$Search%' OR messengerHandle LIKE '%$Search%'
							)");
		foreach($Users as $User)
			$Output[] = new User($User->id);
			
		return $Output;
	}
	
	/**
	 * Returns an array of User objects for all non deleted users within the User table.
	 *
	 * @return Array
	 */
	Public Function getAllNonDeletedUsers()
	{
		$Output = array();
		$Users = $this->_db->fetchAll('SELECT * FROM bevomedia_user WHERE deleted = 0');
		foreach($Users as $User)
			$Output[] = new User($User->id);
			
		return $Output;
	}
	
	
	
	/**
	 * Returns an array of User objects for all non deleted users within the User table and executes the LoadStats() function on each User entry.
	 * 
	 * @see LoadStats()
	 * @return Array
	 */
	Public Function getAllNonDeletedUsersWithStats()
	{
		$Output = array();
		$Users = $this->_db->fetchAll('SELECT * FROM bevomedia_user WHERE Deleted = 0');
		foreach($Users as $User)
		{
			$Temp = new User($User->id);
			$Temp->LoadStats();
			$Output[] = $Temp;
		}	
		return $Output;
	}
	
	/**
	 * Return an array of User objects for all rows within the User table that have been marked as deleted.
	 *
	 * @return Array
	 */
	Public Function getAllDeletedUsers()
	{
		$Output = array();
		$Users = $this->_db->fetchAll('SELECT * FROM bevomedia_user WHERE Deleted = 1');
		foreach($Users as $User)
			$Output[] = new User($User->id);
			
		return $Output;
	}
	
	/**
	 * Return an array of User objects for all rows within the User table that have their Enabled value set to '0'.
	 *
	 * @return Array
	 */
	Public Function getNewApplications()
	{
		$Output = array();
		$Users = $this->_db->fetchAll('SELECT * FROM bevomedia_user WHERE Enabled = 0');
		foreach($Users as $User)
			$Output[] = new User($User->id);
			
		return $Output;
	}
	
	/**
	 * Inserts a new row into the UserInfo table for the specified $User_ID using the information provided within the associative $Data array.
	 *
	 * @param Array $Data
	 * @param Integer $User_ID
	 */
	Public Function InsertInfo($Data, $User_ID)
	{
		$Insert = array();
		$Insert['id'] = $User_ID;
		unset($Data['Password']);
		unset($Data['re-enter_password']);
		unset($Data['Email']);
		unset($Data['registerFormSubmit']);
		unset($Data['EULAAccepted']);
		unset($Data['Timezone']);
		foreach($Data as $Key=>$Value)
		{
			$Insert[$Key] = $Value;
		}
		$this->_db->Insert('bevomedia_user_info', $Insert);
	}
	
	/**
	 * Inserts a new row into the User_Timezone table for the specified $User_ID.
	 *
	 * @param Array $Timezone
	 * @param Integer $User_ID
	 */
	Public Function InsertTimezone($Timezone, $User_ID)
	{
		$Insert = array();
		$Insert['user__id'] = $User_ID;
		$Insert['timezone'] = $Timezone;
		$this->_db->Insert('bevomedia_user_timezone', $Insert);
	}
	
	/**
	 * Update the User_Timezone table and set Timezone to '$Timezone' where the User_ID matches $User_ID.
	 *
	 * @param String $Timezone
	 * @param Integer $User_ID
	 */
	Public Function updateTimezone($Timezone, $User_ID)
	{
		$NumRows = $this->_db->exec("UPDATE bevomedia_user_timezone SET timezone = '$Timezone' WHERE user__id = $User_ID");
		if($NumRows == 0)
		{
			$this->InsertTimezone($Timezone, $User_ID);
		}
	}
	
	/**
	 * Update the User table and set Enabled to '1' where the row ID matches $ID.
	 *
	 * @param Integer $ID
	 */
	Public Function enableUser($ID)
	{
		$this->_db->exec("UPDATE bevomedia_user SET enabled = 1 WHERE id = $ID");
		
		$Sql = "SELECT 
					bevomedia_user.email,
					bevomedia_user_info.firstName,
					bevomedia_user_info.lastName
				FROM 
					bevomedia_user,
					bevomedia_user_info
				WHERE
					(bevomedia_user.id = bevomedia_user_info.id) AND
					(bevomedia_user.id = $ID)		
				";
	
		$UserInfo = $this->_db->fetchRow($Sql);

		$MailComponentObject = new MailComponent();
		$MailComponentObject->setFrom('no-reply@bevomedia.com');
        	
			
		$EmailContent = <<<END

			Dear {$UserInfo->firstName} {$UserInfo->lastName},
		
			Your account with Bevo Media has been created! 
			You are now free to login and begin using your platform. 
			Please note that our platform is in beta. 
			Because of this, it is possible that you come across a bug from time to time. 
			Please report all bugs to beta@bevomedia.com, or by submitting a ticket. 
			We are working to create a perfected platform, and with your help, it can be done much faster!
 
			<br /><br />
 
			When you first log into your account, our tutorial tool will take you on a tour of how our interface works, and the first steps of getting started.
 
			<br /><br />		
 
			If you have any questions, please do not hesitate to ask our support team!
 
			<br /><br />
 
			-The BeVo Media Team
				
END;
        	
        	$MailComponentObject->setSubject('Welcome to the BeVo Media Community!');
            $MailComponentObject->setHTML($EmailContent);
            $MailComponentObject->send(array($UserInfo->email));
		
	}
	
	/**
	 * Update the User table and set Enabled to '0' where the row ID matches $ID.
	 *
	 * @param Integer $ID
	 */
	Public Function disableUser($ID)
	{
		$this->_db->exec("UPDATE bevomedia_user  SET Enabled = 0 WHERE ID = $ID");
	}
	
	/**
	 * Generate and send this User a password reset code so that they may change their password.
	 * If the user already has an outstanding reset code this will remove it and create a new one.
	 */
	Public Function resetPassword()
	{
		$Code = $this->GenerateResetCode();
		$Email = $this->Email;
		$Subject = 'Reset Password Request from ' . $_SERVER['HTTP_HOST'];
		$Body = <<<END
This is an automatically generated email from $_SERVER[HTTP_HOST] regarding a password reset.<br/>
If you did not request a password reset then please disregard this email.<br/>
<br/>
Otherwise, follow this link to reset your password:<br/>
<a href="http://$_SERVER[HTTP_HOST]/BevoMedia/Index/ResetPassword.html?EmailCode=$Code&Email=$Email">http://$_SERVER[HTTP_HOST]/BevoMedia/Index/ResetPassword.html?EmailCode=$Code&Email=$Email</a>
END;
		
		$this->ClearResetCode();
		$this->InsertResetCode($Code);
		$this->SendEmail($Email, $Subject, $Body);
	}
	
	/**
	 * Returns true if the provided password reset $Code matches the existing code for this User.
	 * Returns false otherwise.
	 * 
	 * @param String $Code
	 * @return Boolean
	 */
	Public Function verifyResetCode($Code)
	{
		$Row = $this->_db->fetchRow('SELECT * FROM UserResetPassword WHERE ID = ' . $this->id . ' AND Hash = "' . $Code .'"');
		if(!$Row || !sizeOf($Row))
			return false;
		else
			return true;
			
	}
	
	/**
	 * Update the User table and set Password to specified $NewPassword.
	 *
	 * @param String $NewPassword
	 */
	Public Function changePassword($NewPassword)
	{
		$this->_db->exec("UPDATE bevomedia_user  SET Password = md5('$NewPassword') WHERE ID = $this->id");
	}
	
	/**
	 * Send an email to the specified $To recipient with a subject of $Subject containing $Body.
	 *
	 * @param String $To
	 * @param String $Subject
	 * @param String $Body
	 */
	Private Function sendEmail($To, $Subject, $Body)
	{
		$MailComponentObject = new MailComponent();
		$MailComponentObject->setFrom('no-reply@'.$_SERVER['HTTP_HOST']);
		$MailComponentObject->setSubject($Subject);
		$MailComponentObject->setHTML($Body);
		$MailComponentObject->send(array($To));
	}
	
	/**
	 * Removes all password reset codes for the User matching this $ID.
	 */
	Public Function clearResetCode()
	{
		$this->_db->delete('bevomedia_user_reset_password', 'id = ' . $this->id);
	}
	
	/**
	 * Insert a new row into the UserResetPassword table for this $ID.
	 *
	 * @param String $Code
	 */
	Public Function insertResetCode($Code)
	{
		$Data = array('ID'=>$this->id, 'Hash'=>$Code);
		$this->_db->insert('bevomedia_user_reset_password', $Data);
	}
	
	/**
	 * Return an alphanumeric string with the specified $Length.
	 *
	 * @param Integer $Length
	 * @return String
	 */
	Public Function generateResetCode($Length = 32)
	{
		$Alpha = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz1234567890';
		$Alpha = str_split($Alpha);
		$Output = '';
		while(strlen($Output) < $Length)
		{
			$Output .= $Alpha[rand(0, sizeOf($Alpha)-1)];
		}
		return $Output;
	}
	
	/**
	 * Insert a new row into the User_Tickets table with a Subject of $Subject and a body of $Problem for the User matching this $ID.
	 *
	 * @param String $Subject
	 * @param String $Problem
	 */
	Public Function submitTicket($Subject, $Problem)
	{
		$User = new User();
		$User->getInfo($this->id);
		
		$Message = "
		
		Name: {$User->firstName} {$User->lastName}<br />
		User ID: {$User->id}<br />
		E-mail: {$User->Email}<br />
		User-Agent: {$_SERVER['HTTP_USER_AGENT']}<br />
		IP Address: {$_SERVER['REMOTE_ADDR']}<br />
		Time: ".date('m/d/Y G:i:s T')."<br />
		
		<br />Bug Description:<br/><br/>
		
		{$_POST['BugDescription']}
		
				   ";
				   
	    $Problem .= "\r\n
		
					User-Agent: {$_SERVER['HTTP_USER_AGENT']}\r\n
					IP Address: {$_SERVER['REMOTE_ADDR']}\r\n
					Time: ".date('m/d/Y G:i:s T')."\r\n
		
					";
					
		$Problem = nl2br($Problem);
		
		$Insert = array('Subject'=>$Subject, 'Problem'=>$Problem, 'User_ID'=>$this->id);
		$this->_db->insert('User_Tickets', $Insert);
		
		
		$MailComponentObject = new MailComponent();
		$MailComponentObject->setFrom('no-reply@bevomedia.com');
		
		$MailComponentObject->setSubject('Bug From '.$User->firstName.' '.$User->lastName);
		$MailComponentObject->setHTML($Message);
		$MailComponentObject->send(array('ryan@bevomedia.com'));
		
		
	
		
	}
	
	/**
	 * Returns true if the specified $Email and $Password match a row within the User table.
	 * Returns false if the specified $Email and $Password do not match any rows within the User table.
	 * Returns -1 if the specified $Email and $Password match a row and that User is not Enabled.
	 *
	 * @param String $Email
	 * @param String $Password
	 * @return Mixed
	 */
	Public Function login($Email, $Password)
	{
		if($this->emailExists($Email))
		{
			$Password = ($this->_db->quote($Password));
			$Result = $this->_db->fetchRow("SELECT * FROM bevomedia_user WHERE email = ? AND password = $Password and enabled=1 and deleted=0", $Email);
			if(sizeOf($Result) == 0 || !$Result)
				return false;
			else
			{
				if($Result->enabled)
				{
					$Sql = "UPDATE bevomedia_user SET lastLogin = NOW() WHERE id = ".$Result->id;
					$this->_db->exec($Sql);
					return true;
				}
				else
					return -1;
			}
		}
		return false;
	}
	
	/**
	 * Sets the specified $Property of this object with the specified $Value provided.
	 * 
	 * @param String $Property
	 * @param Mixed $Value
	 * @return Accounts_Abstract
	 */
	Public Function set($Property, $Value)
	{
		$this->{$Property} = $Value;
		return $this;
	}
	
	Public Function getAllAffiliateAccounts()
	{
	  return $this->_db->fetchAll('select un.*, an.title as title from bevomedia_user_aff_network un left join bevomedia_aff_network an on (an.id=un.network__id) where un.user__id='.$this->id);
	}
}
?>