<!-- EMPTY -->

<script language="javascript">
	LayoutAssist.selfLocationTimer(120, '[SELF.LOCATION.HREF]')
</script>