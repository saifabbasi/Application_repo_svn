<?php

class AffNetworkSubIDs extends DBObject {

	function __construct() {
		parent::__construct('adpalace_user_aff_network_subid', 'ID', array('USER__ID', 'NETWORK_ID', 'STAT_DATE','OFFER_ID','SUB_ID','CLICKS','CONVERSIONS','REVENUE'));
	}
	
	

}

?>