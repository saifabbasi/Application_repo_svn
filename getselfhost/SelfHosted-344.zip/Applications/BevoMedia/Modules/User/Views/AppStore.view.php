<div id="pagemenu">
	<ul>
		<li><a class="active" href="<?= Zend_Registry::get('System/BaseURL') ?>BevoMedia/User/AppStore.html">App Store<span></span></a></li>
		<?php // if user has purchased any apps, add them to the My Apps dropdown here! If user has no apps, don't show the My Apps tab at all.
			/*<li><a href="#">My Apps<span></span></a>
				<ul>
					<li>PPV Spy</li>
				</ul>
			</li> */ ?>			
	</ul>
</div>
<?php echo $this->PageDesc->ShowDesc($this->PageHelper, false); //no toggling
?>

<?php 
	require_once( PATH.'PhoneHome.class.php');
	$ph = new PhoneHome();
    $ph->bevo_auth($this->User);
?>

<div class="pagecontent" id="appstore">
	<div class="feat featapp_ppvspy">
		<div class="desc">
			<h3 class="apptitle">Bevo PPV Spy</h3>
			<p>PPV Spy is the only research tool for Pay-Per-View ads in existence. By using it, you will get unique insights into what works for your competitors - and what doesn't. It's all at your fingertips and ready to be replicated.</p>
			
			<a class="btn btn_appstore_watchvideo" rel="shadowbox;width=900;height=506;" href="http://player.vimeo.com/video/17655071?byline=0&amp;portrait=0&amp;color=ff9933&amp;autoplay=1">Watch Video</a>
			
			<h3>Features</h3>
			<ul class="soapchecklist checkwhite">
				<li>Browse and search in thousands of PPV campaigns, offers, and targets</li>
				<li>Data set updated hourly</li>
				<li>Learn what pops are seen the most</li>
				<li>Download full lists of target URLs</li>
				<li>Suggest target URLs you'd like us to add</li>
			</ul>			
		</div>
		
		<div class="testi">
			<h3>What our Beta Testers are saying...</h3>
			<ul>
				<li>I used to spend weeks figuring out what sites to target, how to design my pops, and what offers performed the best. With PPV Spy, I got all that at my fingertips in no time at all. It's amazing.</li>
				<li>I used the PPV Spy last week for the first time. In about 30 minutes, I got a solid new campaign plan and launched it later that day. Right now, my running profit for that campaign is $12,770, and it's my most profitable campaign ever.<br />Thanks Bevo!</li>
				<li>PPV Spy is a total game-changer. Please don't let everyone and their mother use it. It's just too easy now.</li>
				<li>You guys are putting the money in my lap with this tool. I just have to pick it up.</li>
			</ul>
		</div>
		<div class="add2cart">
			<div class="cartdesc">
				<h3>Bevo PPV Spy</h3>
				<p>
				
				<?php 
					if ($this->ppvSignedUp) {
				?>
					You have a valid license for this app.
				<?php 
					} else {
				?>
					Full access to the Bevo PPV Spy App for only $385 /month or a $999 one-time payment.
				<?php 
					}
				?>
				<br /> 
				
				
					
			</p>
					
			</div><!--close cartdesc-->
			
			
			<?php 
				if ($this->ppvSignedUp) {
			?>
			<div class="cartaction check">
				<a class="btn btn_appstore_launchapp_wide" href="http://beta.bevomedia.com/BevoMedia/User/AppStore.html?apiKey=<?php echo $ph->apiKey; ?>" onclick="return BevoLive(this);">Launch App</a>
			</div>
			
			<?php 
				} else {
			?>
			
			<div class="cartaction buy">
				<a class="btn j_add2cart btn_appstore_add2cart_wide" href="http://beta.bevomedia.com/BevoMedia/User/AppStore.html?apiKey=<?php echo $ph->apiKey; ?>" onclick="return BevoLive(this);">Add To Cart</a>
				<small>You'll be able to review your order on the next page</small>
			</div>
			
			<?php 
				}
			?>
			
				
			
				
		</div><!--close add2cart-->
	</div><!--close featapp-->
	
	<div class="moreapps"></div>
	
	
	
	<?php
	/*
	
	
	appbox keyword research (PPVTools)
	
	
	*/ 
	?>
	<div class="item">
		<div class="apptitle">
			<div class="apptitleleft"></div>
			<h3>Bevo Keyword List Builder</h3>
			<div class="apptitleright"></div>
			<?php /*<a class="btn btn_appstore_watchvideo" rel="shadowbox;width=900;height=620;" href="http://www.youtube.com/v/aen5cQn4qEM&hl=en_US&fs=1&autoplay=1">Watch Video</a>*/ ?>
		</div>
		
		<div class="appboxinside">
			<div class="img"><img src="<?php echo SCRIPT_ROOT; ?>img/pagedesc_ppv.png" alt="" /></div>
			<div class="cont">			
				<div class="desc">
					<p>The Bevo Keyword List Builder is a premium keyword research tool designed to save time during the crucial research stages of building a campaign. This tool is a huge leg up on the competition whether you have a search, PPV or media buy campaign. </p>
				</div>
				
				<ul class="soapchecklist">
					<li>Save time and stay ahead of the competition</li>
					<li>Find exact data on keywords and URLs</li>
					<li>Find out exactly where URLs rank on Alexa.com</li>					
				</ul>
				
				<div class="add2cart">
					<div class="cartdesc">
						<h3>Bevo Keyword List Builder</h3>
						<p>The Bevo Keyword List Builder is a premium app is free to use for verified BevoMedia users!</p>
					</div>
					
					<div class="cartaction">
					
							<div class="icon icon_appstore_add2cart_check"></div>
							<a class="btn btn_appstore_launchapp" href="http://beta.bevomedia.com/BevoMedia/User/AppStore.html?apiKey=<?php echo $ph->apiKey; ?>" onclick="return BevoLive(this);">Launch App</a>
							
							<h3>FREE</h3>
							<p>This app is free to use!</p>
					
					</div><!--close cartaction-->
				</div><!--close add2cart-->
			</div><!--close cont-->
			<div class="clear"></div>
		</div><!--close appboxinside-->
	</div><!--close appbox-->
	
	<?php
	/*
	
	
	appbox ppv campaign editor
	
	
	*/ 
	?>
	<div class="item">
		<div class="apptitle">
			<div class="apptitleleft"></div>
			<h3>PPC Campaign Editor</h3>
			<div class="apptitleright"></div>
			<?php /*<a class="btn btn_appstore_watchvideo" rel="shadowbox;width=900;height=620;" href="http://www.youtube.com/v/aen5cQn4qEM&hl=en_US&fs=1&autoplay=1">Watch Video</a>*/ ?>
		</div>
		
		<div class="appboxinside">		
			<div class="img"><img src="<?php echo SCRIPT_ROOT; ?>img/pagedesc_ppc.png" alt="" /></div>
			<div class="cont">			
				<div class="desc">
					<p>Bevo's PPC Management gives you the opportunity not only to examine your search marketing expenses, but also to edit and create all of your campaigns within a single interface. Check out your search campaign stats, create or edit a campaign and gain an in-depth view of exactly where your money is going.</p>
				</div>
				
				<ul class="soapchecklist">
					<li><p>Create Campaigns Faster than Ever</p>
						<span>The Bevo Campaign Editor allows users to upload multiple campaigns, adgroups, keywords and ad variations all at once, requiring the least amout of time possible!</span>
					</li>
					<li><p>Edit Campaigns on the Fly</p>
						<span>Edit your campaigns while browsing through your campaign performance, all on the Bevo interface.</span>
					</li>
					<li><p>Cross-post to Multiple PPC Accounts</p>
						<span>Create a campaigns once and post to multiple Google, Yahoo and Bing accounts in the click of a button. Clone campaigns instantly!</span>
					</li>
				</ul>
				
				<div class="add2cart">
					<div class="cartdesc">
						<h3>PPC Campaign Editor</h3>
						<p>The Bevo PPC Campaign Editor is a premium feature that has a nominal one-time licensing fee, for which you are free to use the feature forever.</p>
					</div>
					
					<div class="cartaction">
								
								<?php  
									if ($ph->ppcSignedUp) {
								?>				
									<div class="icon icon_appstore_add2cart_check"></div>
									<a class="btn btn_appstore_launchapp" href="/BevoMedia/Publisher/CreatePPC.html">Launch App</a>
									
									<p>You have a valid license to use this app</p>						
								<?php 
									} else {
								?>								
									<div class="icon icon_appstore_add2cart_buy"></div>
									<a class="btn j_add2cart btn_appstore_add2cart" href="http://beta.bevomedia.com/BevoMedia/User/AppStore.html?apiKey=<?php echo $ph->apiKey; ?>" onclick="return BevoLive(this);">Add to Cart</a>
									
									<h3>$160</h3>
									<p>One-time license fee</p>
								<?php 
									}
								?>
							
						
					</div><!--close cartaction-->
				</div><!--close add2cart-->
			</div><!--close cont-->
			<div class="clear"></div>
		</div><!--close appboxinside-->
	</div><!--close appbox-->
</div><!--close pagecontent-->

<script type="text/javascript">
$(document).ready(function() {
	$('a.j_add2cart').click(function() {
		var a = document.createElement('a');
		a.href = $(this).attr('rel')+'?ajax=true';
		a.rel = 'shadowbox;width=640;height=480;player=iframe';
		Shadowbox.open(a);
		return false;
	});
});
</script>