<div style="z-index:10000; position: fixed; left: 0px; top: 0px; padding-top: 48px; width: 100%; height: 100%; text-align: center;">
	<img style="border:none;" src="/Themes/BevoMedia/img/LightboxFirst.png" usemap="#mapmap"/>

	<map name="mapmap">
	  <area shape="rect" coords="60,360,250,445" href="/BevoMedia/Publisher/Index.html?STEP=AFFSTEP2" alt="Affiliate" />
	  <area shape="rect" coords="390,360,580,445" href="/BevoMedia/Publisher/Index.html?STEP=FIRMSTEP2" alt="PPC Firm or Business" />
	</map>

	<br/>
	<a href='#' onClick='javascript:firstlogin.close();'>Cancel Tutorial</a>
</div>