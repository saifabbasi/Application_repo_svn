	<div id="pageinfo" class="sub">
		<h2>Investor Information for BeVo Media</h2>
	</div>
	<div class="clear"></div>
	
	<div class="content"> 
<p>BeVo Media LLC is funded entirely by its founders and partners. If you would like to be considered to help us achieve our long term goals as an investor, please contact us at <strong><a href="mailto:investors@bevomedia.com">investors@bevomedia.com<a></strong></p>
	</div>
