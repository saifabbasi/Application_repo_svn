<div id="pagemenu">
	<ul>
		<li><a href="/BevoMedia/Publisher/PPCManager.html">Overview<span></span></a></li>
		<li><a class="active" href="/BevoMedia/Publisher/CreatePPC.html">Campaign Editor<span></span></a></li>
	</ul>
	<ul class="floatright">
		<li><a onclick="return BevoLive(this);" href="http://beta.bevomedia.com/BevoMedia/Publisher/PPCQueueProgress.html?apiKey=<?php echo $this->User->getApiKey()?>">Campaign Editor Queue<span></span></a></li>
	</ul>
</div>
<?php echo $this->PageDesc->ShowDesc($this->PageHelper,false); ?>
<script src='/Themes/BevoMedia/createppc.js'></script>