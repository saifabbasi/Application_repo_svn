<!DOCTYPE TS><TS>
<context>
    <name>ErrorDlg</name>
    <message>
        <source>Sorry, but this is a 404 Error</source>
        <translation type="RCS Framework">Sorry, but this is a 404 Error</translation>
    </message>
    <message>
        <source>This page doesn't exist</source>
        <translation type="RCS Framework">This page doesn't exist</translation>
    </message>
    <message>
        <source>404 Error</source>
        <translation type="RCS Framework">404 Error</translation>
    </message>
    <message>
        <source>Page Description</source>
        <translation type="RCS Framework">Page Description</translation>
    </message>
    <message>
        <source>Some, More, Keywords</source>
        <translation type="RCS Framework">Some, More, Keywords</translation>
    </message>
    <message>
        <source>500 Error</source>
        <translation type="RCS Framework">500 Error</translation>
    </message>
     <message>
        <source>Sorry, but this is a 500 Error</source>
        <translation type="RCS Framework">Sorry, but this is a 500 Error</translation>
    </message>
    <message>
        <source>There was a system error</source>
        <translation type="RCS Framework">There was a system error</translation>
    </message>
</context>

</TS>
