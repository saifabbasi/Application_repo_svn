<?php
/**
 * User Controller
 */

/**
 * User Controller
 *
 * Controller for generic User related pages such as processing log in attempts, changing the user's password, updating profile information,
 * submitting a ticket and more.
 * @category   RCS Framework
 * @package    Controllers
 * @subpackage UsersController
 * @copyright  Copyright (c) 2009 RCS
 * @author RCS
 * @version 0.1.2
 */

require_once(Zend_Registry::get('Application/TrueWorkingDirectory') .'Applications/'. Zend_Registry::get('Instance/Application') .'/Common/IncludeHelper.include.php');

Class UserController extends ClassComponent
{
	
	/**
	 * @var Mixed $GUID
	 */
	Public $GUID		= NULL;
	
	/**
	 * Constructor
	 */
	Public Function __construct()
	{
		parent::GenerateGUID();
		$this->{'PageHelper'} = new PageHelper();
		$this->{'PageDesc'} = new PageDesc();
		$_db = Zend_Registry::get('Instance/DatabaseObj');
		
		$this->db = $_db;
		if(isset($_SESSION['User']['ID']))
		{
			$user = new User();
			$user->getInfo($_SESSION['User']['ID']);
			$this->{'User'} = $user;
			Zend_Registry::set('Instance/LayoutType', 'logged-in-layout');
		}
		
		
		$page = Zend_Registry::get('Instance/Function');
		if(!isset($_SESSION['User']) || !intval($_SESSION['User']['ID']))
		{
			$noLoginNeeded = array('Register', 'Login', 'ProcessLogin');
			if(!in_array($page, $noLoginNeeded))
			{
				$_SESSION['loginLocation'] = $_SERVER['REQUEST_URI'];
				header('Location: /BevoMedia/Index/');
				die;
			}
		}
		
	}
	
	/**
	 * Publisher PPC Accounts Page Functionality
	 */
	Public Function PublisherPPCAccounts()
	{
		$User = $this->User;
		$this->AdwordsResults = $User->GetAllAccountsAdwords();
		$this->YahooResults = $User->GetAllAccountsYahoo();
		$this->MSNResults = $User->GetAllAccountsMSN();
	}
	
	/**
	 * Change Password Page Functionality
	 */
	Public Function ChangePassword()
	{
		Zend_Registry::set('Instance/LayoutType', 'shadowbox-layout');
		
		$this->Message = false;
		
		if(isset($_POST['changePasswordSubmit']))
		{
			$User = new User($_SESSION['User']['ID']);
			$Valid = $User->Login($User->email, md5($_POST['OldPassword']));
			if(!$Valid || $_POST['NewPassword'] == '' || $_POST['ReNewPassword'] == '' || $_POST['ReNewPassword'] != $_POST['NewPassword'])
				$this->Message = 'INVALID_PASS';
			else {
				$User->ChangePassword($_POST['NewPassword']);
				$this->Message = 'PASS_CHANGED';
			}
		}
	}
	
	Public Function UpdateSelfHostedBackground()
	{
			Zend_Registry::set('Instance/LayoutType', 'blank-layout');
	}
	
	Public Function LightboxFirst()
	{
		Zend_Registry::set('Instance/LayoutType', 'blank-layout');
		
	}
	
	Public Function LightboxTemplate_Final()
	{
		Zend_Registry::set('Instance/LayoutType', 'blank-layout');
		$this->PresetItem = $_GET['STEP'];
		$this->Presets = array(
			'AFFSTEP2'=>array('TITLE'=>'My Networks', 'LINK'=>'/BevoMedia/Publisher/PPCManager.html?STEP=AFFSTEP3', 'CONTENT'=>'Great! BeVo Media is specifically molded towards affiliate marketers to help manage affiliate networks, offers, conversion statistics, PPC Accounts, Media Buys and more!<br/><br/>This is the My Networks Page. Scroll through the page and install your affiliate networks, PPC Accounts, and analytics accounts. The My Networks page is also a great place to learn what other publishers rate their user experience with a network. Feel free to rate your favorite, and least favorite networks! '),
			'AFFSTEP3'=>array('TITLE'=>'PPC Management', 'LINK'=>'/BevoMedia/KeywordTracker/Overview.html?STEP=AFFSTEP4', 'CONTENT'=>'After you install your PPC Accounts you can drill down your account statistics from an account, campaign, adgroup, ad variation and keyword level. If something needs to be changed, you have the ability to easily edit a campaign through the Bevo Interface. <br/><br/>Within the PPC Management Section, is the Bevo Editor. The Bevo Editor allows publishers to easily create campaigns in their entirety. The Bevo Editor features the Cross Post feature that allows users to create a campaign, and then post that campaign to multiple PPC Accounts at once! '),
			'AFFSTEP4'=>array('TITLE'=>'Keyword Tracker', 'LINK'=>'/BevoMedia/Analytics/AnalyticsDetail.html?STEP=AFFSTEP5', 'CONTENT'=>'Bevo Track is a full scale Keyword tracker with API integrated subID, pixel, and postback methods available. Additionally, within Bevo Track is a complete media buy tracker, reporting your statistics in the most complete, simplistic form possible. Simply put, BevoTrack is the most effortless, yet data intensive keyword tracker on the net!'),
			'AFFSTEP5'=>array('TITLE'=>'Analytics', 'LINK'=>'/BevoMedia/Marketplace/Index.html?STEP=AFFSTEP6', 'CONTENT'=>'After you install your analytics accounts, you can easily view your traffic statistic on the Bevo Interface. No need to log in to multiple analytic accounts to keep track of all of your sites, Bevo brings it all to you on one interface! '),
			'AFFSTEP8'=>array('TITLE'=>'Tutorial Complete!', 'DONE'=>TRUE, 'LINK'=>'#', 'CONTENT'=>'That\'s it! Feel free to click around and contact your assigned mentor if you have any questions.<br/><br/>Are you a big publisher and want to host all of this on your own server? Check out the Self Hosted Version <a href="/BevoMedia/User/SelfHostedLogin.html">Here</a>.'),
			
			'FIRMSTEP2'=>array('TITLE'=>'My Networks', 'LINK'=>'/BevoMedia/Publisher/PPCManager.html?STEP=FIRMSTEP3', 'CONTENT'=>'The Bevo Media Platform was developed specifically to help facilitate the online marketing efforts for businesses and PPC Firms. As a company, you will have the ability to manage multiple Pay Per Click accounts, Analytic accounts, and track your campaign success in an easy, clear cut manor. <br/><br/>This is the My Networks page. On this page, you install all of your pay per click and analytic accounts. You need to do this before you can access your accounts on the Bevo interface. '),
			'FIRMSTEP3'=>array('TITLE'=>'PPC Management', 'LINK'=>'/BevoMedia/KeywordTracker/Overview.html?STEP=FIRMSTEP4', 'CONTENT'=>'After you install your PPC Accounts you can drill down your account statistics from an account, campaign, adgroup, ad variation and keyword level. If something needs to be changed, you have the ability to easily edit a campaign through the Bevo Interface. <br/><br/>Within the PPC Management Section, is the Bevo Editor. The Bevo Editor allows publishers to easily create campaigns in their entirety. The Bevo Editor features the Cross Post feature that allows users to create a campaign, and then post that campaign to multiple PPC Accounts at once! '),
			'FIRMSTEP4'=>array('TITLE'=>'Keyword Tracker', 'LINK'=>'/BevoMedia/Analytics/AnalyticsDetail.html?STEP=FIRMSTEP5', 'CONTENT'=>'Bevo Media has a  built in keyword tracker. Easily track you campaign performance by the various tracking methods provided. All forms of the tracker are API integrated, making it the most simplistic setup keyword tracker on the net.  '),
			'FIRMSTEP5'=>array('TITLE'=>'Analytics', 'LINK'=>'/BevoMedia/Marketplace/Index.html?STEP=FIRMSTEP6', 'CONTENT'=>'After you install your analytics accounts, you can easily view your traffic statistic on the Bevo Interface. No need to log in to multiple analytic accounts to keep track of all of your sites, Bevo brings it all to you on one interface! '),
			'FIRMSTEP8'=>array('TITLE'=>'Tutorial Complete!', 'DONE'=>TRUE, 'LINK'=>'#', 'CONTENT'=>'That\'s it! Feel free to click around and contact your assigned mentor if you have any questions.<br/><br/>Interested in having a customized version of Bevo Media for your company? Check out our Customized Version <a href="/BevoMedia/User/SelfHostedLogin.html">Here</a>.'),
		);
	}
	
	/**
	 * Change Profile Page Functionality
	 */
	Public Function ChangeProfile()
	{
		if(isset($_POST['changeProfileFormSubmit']))
		{
			$Data = $_POST;
			unset($Data['changeProfileFormSubmit']);
			$this->User->Update($Data);
			$this->Message = 'ACCOUNT_UPDATED';
		}
	}
	
	/**
	 * Process Login Page Functionality
	 */
	Public Function ProcessLogin()
	{
		if(isset($_POST['loginFormSubmit']))
		{
		    		
			$LoginPage = '/BevoMedia/Index/SelfHostedLogin.html';
			$user = new User();
			
			$loginAttempt = $user->login($_POST['Email'], md5($_POST['Password']));
			if($loginAttempt === true)
			{
			    $userId = $user->getIdUsingEmail($_POST['Email']);
    			$user->getInfo($userId);
				setcookie('BEVO_REMEMBER_LOGIN_ID', $user->id, time()+60*60*24*30, '/');
				$_SESSION['User']['ID'] = $userId;
				if(isset($_SESSION['loginLocation']) && !strstr($_SESSION['loginLocation'], '_') )
				{
					header('Location: ' . $_SESSION['loginLocation']);
					unset($_SESSION['loginLocation']);
				}else{
					header('Location: /BevoMedia/User/Index.html');
				}
			}
			else
				if($loginAttempt == -1)
					header('Location: '.$LoginPage.'?Error=DISABLED');
				else
					header('Location: '.$LoginPage.'?Error=BADPASS');
		}
        die;
	}
	
	/**
	 * Logout Page Functionality
	 */
	Public Function Logout()
	{
		$user = new User();
		$user->Logout();
		if(isset($_COOKIE['BEVO_REMEMBER_LOGIN_ID']))
		{
			unset($_COOKIE['BEVO_REMEMBER_LOGIN_ID']);
			setcookie('BEVO_REMEMBER_LOGIN_ID', 0, time() - 3600, '/');
		}
		header('Location: /BevoMedia/Index/Index.html');
		die;
	}
	
	/**
	 * Empty Page Page Functionality
	 */
	Public Function EmptyPage()
	{
		Zend_Registry::set('Instance/LayoutType', 'shadowbox-layout');
		print_r($_SESSION);
		$_SESSION['extendSessionHack'] = time();
	}
	
	Public Function SelfHostedLogin()
	{
		if($this->User->IsSelfHosted() == '1')
		{
			header('location: /BevoMedia/User/SelfHostedLoginDownload.html');
			exit;
		}
	}

	Public Function SelfHostedAdmin()
	{
		require_once(PATH.'PhoneHome.class.php');
		$this->AllUsers = $this->db->fetchAll('select * from bevomedia_user');
		$this->PH = new PhoneHome();
	}
	
	Public Function DisassociateLiveAccount()
	{
		if(isset($_GET['id']))
		{
			$this->db->exec('DELETE FROM bevomedia_dotcom_accounts WHERE id='.intval($_GET['id']));
		}
		header('Location: ' . $_SERVER['HTTP_REFERER']);
		die;
	}
	
	Public Function BevoLiveAuth()
	{
		if(isset($_GET['Ajax']))
		{
			$checkBevoLiveUrl = ($_SERVER['HTTP_HOST'] == 'bsh' ? 'http://bevolocal' : 'http://beta.bevomedia.com' ). '/BevoMedia/API/SelfHostedAuthentication.html?username='.@$_GET['u'].'&password='.@$_GET['p'];
			echo $checkBevoLiveUrl;
	        $bevo_response = file_get_contents($checkBevoLiveUrl);
	        $vars = json_decode($bevo_response);
	        if(isset($vars->apiKey) && !isset($vars->error))
	        {
	            $this->db->insert('bevomedia_dotcom_accounts', array('username' => $_GET['u'], 'password' => $_GET['p'], 'user__id' => $_GET['uid']));
	            echo "<jsCallFunction>parent.window.location = parent.window.location;</jsCallFunction>";
	            die;
	        }
		}
		echo '<jsCallFunction>alert("The Bevomedia.com credentials you entered are incorrect!");</jsCallFunction>';
		die;
	}
	Public Function AddLiveAccount()
	{
		Zend_Registry::set('Instance/LayoutType', 'shadowbox-layout');
	}
	
	Public Function AddUser()
	{
		if(isset($_POST['username']))
		{
			$this->db->insert('bevomedia_user', array('email' => $_POST['username'], 'password' => md5($_POST['password'])));
			echo '<script>parent.window.location = parent.window.location;</script>';
			die;
		}
		Zend_Registry::set('Instance/LayoutType', 'shadowbox-layout');
	}
	
	Public Function EnableUser()
	{
		if(isset($_GET['id']))
		{
			$this->db->update('bevomedia_user', array('enabled' => 1), 'id='.$_GET['id']);
		}
		
		header('Location: ' . $_SERVER['HTTP_REFERER']);
		die;
	}
	
	Public Function DisableUser()
	{
		if(isset($_GET['id']))
		{
			$this->db->update('bevomedia_user', array('enabled' => 0), 'id='.$_GET['id']);
		}
		
		header('Location: ' . $_SERVER['HTTP_REFERER']);
		die;
	}
	
	Public Function DeleteUser()
	{
		if(isset($_GET['id']))
		{
			$User = new User();
			$User->DeleteUser($_GET['id']);
		}
		
		header('Location: ' . $_SERVER['HTTP_REFERER']);
		die;
	}
	
	Public Function RestoreUser()
	{
		if(isset($_GET['id']))
		{
			$User = new User();
			$User->RestoreUser($_GET['id']);
		}
		
		header('Location: ' . $_SERVER['HTTP_REFERER']);
		die;
	}
	Public Function EULA()
	{
		Zend_Registry::set('Instance/LayoutType', 'shadowbox-layout');
	}


    Public Function ManageStats()
	{
		$this->AdwordsResults = $this->User->getAllAccountsAdwords();
		$this->YahooResults = $this->User->getAllAccountsYahoo();
		$this->MSNResults = $this->User->getAllAccountsMSN();
		$this->AffResults = $this->User->getAllAffiliateAccounts();
		$this->deleted = false;
		if(!empty($_POST))
		{
	      $dateArray = explode(' - ', $_POST['date']);
	      if (count($dateArray)==1)
	      {
	      	$s = $e = $dateArray[0];
	      } else
	      {
	      	$s = $dateArray[0];
	      	$e = $dateArray[1];
	      }
		  $s = date('Y-m-d', strtotime($s));
		  $e = date('Y-m-d', strtotime($e));
	      
		  $user = 'user__id='.$this->User->id;
//		  $s = date('Y-m-d', strtotime($_POST['sdate']));
//		  $e = date('Y-m-d', strtotime($_POST['edate']));
		  $btwn = "BETWEEN '$s' AND '$e'";
		  // Delete Keyword Tracker Stats
		  if(@$_POST['kw'] == 'on')
		  {
			$this->db->delete('bevomedia_tracker_clicks_optional', "clickId in (select id from bevomedia_tracker_clicks where $user and clickDate $btwn)");
			$this->db->delete('bevomedia_tracker_clicks', "$user and clickDate $btwn");
			$this->deleted = true;
		  }

		  // Delete Affiliate Network Stats
		  if(@$_POST['aff'] == 'on')
		  {
			$nets = implode(',', array_keys($_POST['AffNetwork']));
			$this->db->delete('bevomedia_user_aff_network_subid', "$user and statDate $btwn and network__id in ($nets)");
			$this->deleted = true;
		  }
		  // Delete PPC Tracker Stats
		  if(@$_POST['ppc'] == 'on')
		  {
		  	
			$gIds = @implode(',', array_map(intval, array_keys($_POST['Adwords'], 'on')));
			$yIds = @implode(',', array_map(intval, array_keys($_POST['Yahoo'], 'on')));
			$mIds = @implode(',', array_map(intval, array_keys($_POST['MSN'], 'on')));
			$wheres = array();
			if(!empty($gIds)) $wheres[] = "(providerType=1 and accountId in ($gIds))";
			if(!empty($yIds)) $wheres[] = "(providerType=2 and accountId in ($yIds))";
			if(!empty($mIds)) $wheres[] = "(providerType=3 and accountId in ($mIds))";
			if(count($wheres))
			{	
			  $cWhere = "where $user AND (" . implode(' OR ', $wheres).")";
			  $cIds = "select id from bevomedia_ppc_campaigns $cWhere";
			  $agIds = "select id from bevomedia_ppc_adgroups where campaignId in ($cIds)";
			  
			  			  
			  $this->db->exec("delete from bevomedia_ppc_advariations_stats where statDate $btwn AND advariationsId in (select id from bevomedia_ppc_advariations where adGroupId in ($agIds))");
			  $this->db->exec("delete from bevomedia_ppc_keywords_stats where statDate $btwn AND keywordId in (select id from bevomedia_ppc_keywords where adGroupId in ($agIds))");
			  $this->db->exec("delete from bevomedia_ppc_contentmatch_stats where statDate $btwn AND adGroupId in ($agIds)");
			  $this->deleted = true;
			}
		  }
		}
	}
	
}

?>