<?php

class NetworkStats extends DBObject {

	function __construct() {
		parent::__construct('adpalace_user_aff_network_stats', 'ID', array('USERID', 'NETWORK_ID', 'STAT_DATE', 'IMPRESSIONS', 'CLICKS', 
'CONVERSIONS', 'REVENUE', 'ECPM'));
	}
	
	function GetListByUserID($intInUserID, $intInNetworkID, $inStartDate = '', $inEndDate = '') {
		if (!is_numeric($intInUserID)) {
			return false;
		}
		
		if (!is_numeric($intInNetworkID)) {
			return false;
		}
		
		if (!empty($inStartDate)) {
			$strWhere = 'adpalace_user_aff_network_stats.Stat_Date >= \'' . date('Y-m-d', strtotime($inStartDate)) . '\'';
			
			if (!empty($inEndDate)) {
				$strWhere .= ' AND adpalace_user_aff_network_stats.Stat_Date <= \'' . date('Y-m-d', strtotime($inEndDate)) . '\'';
			}
			
			if (strlen($strWhere) > 1) {
				$strWhere = ' AND (' . $strWhere . ') ';
			}
		}
		
		$strSQL = 'SELECT SUM(Clicks) AS ClickSum, SUM(Conversions) AS ConvSum, SUM(Revenue) AS NetRevenue FROM adpalace_user_aff_network_stats
					WHERE (adpalace_user_aff_network_stats.USERID = ' . $intInUserID . ' AND 
adpalace_user_aff_network_stats.NETWORK_ID = ' 
. $intInNetworkID . ') ';
		$strSQL .= $strWhere;
		
		$this->Select($strSQL);
	}

}

?>
