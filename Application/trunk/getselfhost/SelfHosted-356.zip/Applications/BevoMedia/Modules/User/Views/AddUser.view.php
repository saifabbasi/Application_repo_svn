<form method="POST" id="addUserForm">
<table>
<tr class="shh">
	<td>
		Username:<br />
	</td>
	<td>
		<input type="text" id="blu" name="username" value="" />
	</td>
</tr>
<tr class="shh">
	<td>
		Password:<br />
	</td>
	<td>
		<input type="password" id="blp" name="password" value="" />
	</td>
</tr>
<tr>
	<td>
		<input type="image" src="/Themes/BevoMedia/img/gobutton.gif" width="30" height="25">
	</td>
	<td>
	<div id="Result"></div>
	</td>
</tr>
</table>
</form>