<?php
ignore_user_abort(true);
require_once(PATH.'PhoneHome.class.php');
$ph = new PhoneHome();
$ph->bevo_auth($this->User);
echo 'Your version: ' . $ph->thisVersion() . '<br />Newest version: ' . $ph->latestBeta . ($ph->latestBeta < $ph->thisVersion() && @$_GET['force'] == 'true' ? ', Upgrading anyway' : '' ). '<br />';
if(!$ph->newVersion() && @$_GET['force'] != 'true')
{
    echo "Already at the newest version.";
}
elseif($ph->doUpgrade())
{
	mysql_query('delete from bevomedia_settings where name="selfhost_version"');
	mysql_query('insert into bevomedia_settings (name, value) values ("selfhost_version", '.$ph->latestBeta.')');
//	echo '<h3>Upgrade complete!</h3>';
}