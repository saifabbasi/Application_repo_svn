	<div id="pageinfo" class="sub">
		<h2>Press Info for BeVo Media</h2>
	</div>
	<div class="clear"></div>
	
	<div class="content"> 
		<p>If you are a member of the media and/or would like to include the BeVo Media name in a press story please write to <strong>press@bevomedia.com</strong>.</p>
	</div>
