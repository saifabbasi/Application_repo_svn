<?php

class NetworkOffers extends DBObject {

	function __construct() {
		parent::__construct('adpalace_offers', 'ID', array('ID', 'NETWORK_ID', 'CATEGORY_ID', 'USERID', 'OFFER_ID', 'TITLE', 'DETAIL', 'LAUNCHED_ON', 'EXPIRES_ON', 'PAYOUT', 'NETWORK_EARNINGS', 'EPC', 'search_allow', 'search_rest', 'email_allow', 'email_ligne', 'email_rules', 'incentives_allow', 'country', 'popularityrank', 'HasRecurringProducts', 'Gravity', 'PercentPerSale', 'TotalEarningsPerSale', 'Referred', 'TotalRebillAmt', 'commission', 'advID', 'instoke', 'isbn', 'manifacturername', 'price', 'retailprice', 'saleprice', 'sku', 'upc', 'REDIRECT_LINK', 'CREATIVE_DOWNLOAD_URL', 'TRACKING_CODES_URL',	'DATE_ADDED', 'EXTRA_TERMS', 'IMAGE_URL', 'APPROVE_LINE'));
	}

	function DeleteByNetworkID($intInNetworkID) {
		$strSQL = 'DELETE FROM adpalace_offers WHERE (NETWORK_ID = ' . $intInNetworkID . ')';
		$this->Query($strSQL);
	}
}
?>
