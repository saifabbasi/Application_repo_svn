<script type="text/javascript" src="<?=$this->{'System/BaseURL'};?>JS/jquery.md5.js"></script>
<script>
function makeRequest(url, div)
{
    try
    {
        var httpRequest;

        if (window.XMLHttpRequest) { // Mozilla, Safari, ...
            httpRequest = new XMLHttpRequest();
            if (httpRequest.overrideMimeType) {
                httpRequest.overrideMimeType("text/xml");
                // See note below about this line
            }
        }
        else if (window.ActiveXObject) { // IE
            try {
                httpRequest = new ActiveXObject("Msxml2.XMLHTTP");
                }
                catch (e) {
                           try {
                                httpRequest = new ActiveXObject("Microsoft.XMLHTTP");
                               }
                             catch (e) {}
                          }
                                       }

        if (!httpRequest) {
            alert("Giving up :( Cannot create an XMLHTTP instance");
            return false;
        }
        httpRequest.onreadystatechange = function()
        {
            if (eval("typeof " + "alertContents" + " == 'function'"))
            {
                alertContents(httpRequest, div);
            }
        };
        httpRequest.open("GET", url, true);
        httpRequest.send("");
    }
    catch (err)
    {
    
    }

}

function alertContents(httpRequest, div)
{
    try
    {
        if (httpRequest.readyState == 4)
		{
            if (httpRequest.status == 200)
            {
                
                var responseText = httpRequest.responseText;
                if (httpRequest.responseText.indexOf("<jsReloadPage")>-1)
                {
                    location.reload(true);
                }
                
                if (httpRequest.responseText.indexOf("<jsCallFunction")>-1)
                {
                    var functionName = httpRequest.responseText.substr(httpRequest.responseText.indexOf("<jsCallFunction>")+("<jsCallFunction>").length);
                    functionName = functionName.substr(0, functionName.indexOf("</jsCallFunction>"));
                    //responseText = responseText.substr(responseText.indexOf("</jsCallFunction>")+("</jsCallFunction>").length);
                    
                    responseText = responseText.replace('<jsCallFunction>'+functionName+'</jsCallFunction>', '');
                    eval(functionName);
                }

       
                document.getElementById(div).innerHTML = responseText;
            } else
			{
                //alert("There was a problem with the request.");
            }
        }
    
    }
    catch (err)
    {
    
    }

}
function CheckCredentials() {
	ajax = 'BevoLiveAuth.html?Ajax=true&';
	if(jQuery('#blu').val().length < 2)
	{
		alert("Please enter a valid username!");
		return;
	}
	if(jQuery('#blp').val().length < 2)
	{
		alert("Please enter a valid password!");
		return;
	}
	makeRequest(ajax+'&u='+jQuery('#blu').val()+'&p='+jQuery("#blp").val()+'&uid=<?= intval($_GET['id']) ;?>', 'Result');
}
</script>
<form onsubmit="CheckCredentials(); return false;">
<table>
<tr class="shh">
	<td>
		Bevomedia.com Username:<br />
	</td>
	<td>
		<input type="text" id="blu" name="blu" value="" />
	</td>
</tr>
<tr class="shh">
	<td>
		Bevomedia.com Password:<br />
	</td>
	<td>
		<input type="password" id="blp" name="blp" value="" />
	</td>
</tr>
<tr>
	<td>
		<input type="submit" name="submit" value="Submit" />
	</td>
	<td>
	<div id="Result"></div>
	</td>
</tr>
</table>
</form>