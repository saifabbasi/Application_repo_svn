<?php

class KeywordTrackerClicks extends DBObject {

	function __construct() {
		parent::__construct('keyword_tracker_clicks', 'ID', array('UserID', 'SubID', 'BidKeywordID', 'RawKeywordID', 'IP', 'Referrer', 'LandingPage', 'ClickDate'));
	}
	
	function GetClickStats($intInUserID, $inStartDate, $inEndDate) {
		if (!is_numeric($intInUserID)) {
			return false;
		}
		
		if (!empty($inStartDate)) {
			$strWhere = 'ClickDate >= \'' . date('Y-m-d', strtotime($inStartDate)) . '\'';
			
			if (!empty($inEndDate)) {
				$strWhere .= ' AND ClickDate <= \'' . date('Y-m-d', strtotime($inEndDate)) . '\'';
			}
			
			if (strlen($strWhere) > 1) {
				$strWhere = ' AND (' . $strWhere . ') ';
			}
		}
	
		$strSQL = 'SELECT SubID, BidKeywordID, RawKeywordID, IP, Referrer, LandingPage, ClickDate, k1.Keyword AS BidKeyword, k2.Keyword AS RawKeyword FROM
					(keyword_tracker_clicks LEFT JOIN keyword_tracker_keywords k1 ON keyword_tracker_clicks.BidKeywordID = k1.ID)
					LEFT JOIN keyword_tracker_keywords k2 ON keyword_tracker_clicks.RawKeywordID = k2.ID
					WHERE (keyword_tracker_clicks.UserID = ' . $intInUserID . ') ';
		$strSQL .= $strWhere;
		$this->Select($strSQL);
	}
	
	function GetKeywordStats($intInUserID, $inStartDate, $inEndDate) {
		if (!is_numeric($intInUserID)) {
			return false;
		}
		
		if (!empty($inStartDate)) {
			$strWhere = 'ClickDate >= \'' . date('Y-m-d', strtotime($inStartDate)) . '\'';
			
			if (!empty($inEndDate)) {
				$strWhere .= ' AND ClickDate <= \'' . date('Y-m-d', strtotime($inEndDate)) . '\'';
			}
			
			if (strlen($strWhere) > 1) {
				$strWhere = ' AND (' . $strWhere . ') ';
			}
		}
		
		$strSQL = 'SELECT BidKeywordID, keyword_tracker_keywords.Keyword AS BidKeyword, COUNT(keyword_tracker_keywords.ID) AS KeywordCount,
						SUM(ADPALACE_USER_AFF_NETWORK_SUBID.Clicks) AS KeywordClicks, SUM(ADPALACE_USER_AFF_NETWORK_SUBID.Conversions) AS KeywordConversions, SUM(ADPALACE_USER_AFF_NETWORK_SUBID.Revenue) AS KeywordRevenue,
						KeywordCost, KeywordCPC
					FROM ((keyword_tracker_clicks LEFT JOIN keyword_tracker_keywords ON keyword_tracker_clicks.BidKeywordID = keyword_tracker_keywords.ID)
					LEFT JOIN ADPALACE_USER_AFF_NETWORK_SUBID ON keyword_tracker_clicks.SubID = ADPALACE_USER_AFF_NETWORK_SUBID.SUB_ID)
						LEFT JOIN (SELECT ppc_keywords.KeywordID, SUM(Cost) AS KeywordCost, AVG(CPC) AS KeywordCPC FROM ppc_keywords_stats LEFT JOIN ppc_keywords ON ppc_keywords_stats.KeywordID = ppc_keywords.ID WHERE StatDate >= \'' . date('Y-m-d', strtotime($inStartDate)) . '\' AND StatDate <= \'' . date('Y-m-d', strtotime($inEndDate)) . '\' GROUP BY KeywordID) AS KeywordStats ON BidKeywordID = KeywordStats.KeywordID
					WHERE (keyword_tracker_clicks.UserID = ' . $intInUserID . ') ';
		$strSQL .= $strWhere;
		$strSQL .= ' GROUP BY BidKeywordID, BidKeyword, KeywordCost, KeywordCPC';
		$this->Select($strSQL);
	}
	
	function GetRawKeywordStats($intInUserID, $inStartDate, $inEndDate) {
		if (!is_numeric($intInUserID)) {
			return false;
		}
		
		if (!empty($inStartDate)) {
			$strWhere = 'ClickDate >= \'' . date('Y-m-d', strtotime($inStartDate)) . '\'';
			
			if (!empty($inEndDate)) {
				$strWhere .= ' AND ClickDate <= \'' . date('Y-m-d', strtotime($inEndDate)) . '\'';
			}
			
			if (strlen($strWhere) > 1) {
				$strWhere = ' AND (' . $strWhere . ') ';
			}
		}
		
		$strSQL = 'SELECT RawKeywordID, keyword_tracker_keywords.Keyword AS RawKeyword, COUNT(keyword_tracker_keywords.ID) AS KeywordCount,
						SUM(ADPALACE_USER_AFF_NETWORK_SUBID.Clicks) AS KeywordClicks, SUM(ADPALACE_USER_AFF_NETWORK_SUBID.Conversions) AS KeywordConversions, SUM(ADPALACE_USER_AFF_NETWORK_SUBID.Revenue) AS KeywordRevenue,
						KeywordCost, KeywordCPC
					FROM ((keyword_tracker_clicks LEFT JOIN keyword_tracker_keywords ON keyword_tracker_clicks.RawKeywordID = keyword_tracker_keywords.ID)
					LEFT JOIN ADPALACE_USER_AFF_NETWORK_SUBID ON keyword_tracker_clicks.SubID = ADPALACE_USER_AFF_NETWORK_SUBID.SUB_ID)
						LEFT JOIN (SELECT ppc_keywords.KeywordID, SUM(Cost) AS KeywordCost, AVG(CPC) AS KeywordCPC FROM ppc_keywords_stats LEFT JOIN ppc_keywords ON ppc_keywords_stats.KeywordID = ppc_keywords.ID WHERE StatDate >= \'' . date('Y-m-d', strtotime($inStartDate)) . '\' AND StatDate <= \'' . date('Y-m-d', strtotime($inEndDate)) . '\' GROUP BY KeywordID) AS KeywordStats ON RawKeywordID = KeywordStats.KeywordID
					WHERE (keyword_tracker_clicks.UserID = ' . $intInUserID . ') ';
		$strSQL .= $strWhere;
		$strSQL .= ' GROUP BY RawKeywordID, RawKeyword, KeywordCost, KeywordCPC';
		$this->Select($strSQL);
	}
	
	function GetRawKeywordStatsByBidKeyword($intInUserID, $intInBidID, $inStartDate, $inEndDate) {
		if (!is_numeric($intInUserID)) {
			return false;
		}
		
		if (!is_numeric($intInBidID)) {
			return false;
		}
		
		if (!empty($inStartDate)) {
			$strWhere = 'ClickDate >= \'' . date('Y-m-d', strtotime($inStartDate)) . '\'';
			
			if (!empty($inEndDate)) {
				$strWhere .= ' AND ClickDate <= \'' . date('Y-m-d', strtotime($inEndDate)) . '\'';
			}
			
			if (strlen($strWhere) > 1) {
				$strWhere = ' AND (' . $strWhere . ') ';
			}
		}
		
		$strSQL = 'SELECT RawKeywordID, keyword_tracker_keywords.Keyword AS RawKeyword, COUNT(DISTINCT keyword_tracker_clicks.ID) AS KeywordCount,
						SUM(ADPALACE_USER_AFF_NETWORK_SUBID.Clicks) AS KeywordClicks, SUM(ADPALACE_USER_AFF_NETWORK_SUBID.Conversions) AS KeywordConversions, SUM(ADPALACE_USER_AFF_NETWORK_SUBID.Revenue) AS KeywordRevenue
					FROM (keyword_tracker_clicks LEFT JOIN keyword_tracker_keywords ON keyword_tracker_clicks.RawKeywordID = keyword_tracker_keywords.ID)
					LEFT JOIN ADPALACE_USER_AFF_NETWORK_SUBID ON keyword_tracker_clicks.SubID = ADPALACE_USER_AFF_NETWORK_SUBID.SUB_ID
						LEFT JOIN (SELECT ppc_keywords.KeywordID, SUM(Cost) AS KeywordCost, AVG(CPC) AS KeywordCPC FROM ppc_keywords_stats LEFT JOIN ppc_keywords ON ppc_keywords_stats.KeywordID = ppc_keywords.ID WHERE StatDate >= \'' . date('Y-m-d', strtotime($inStartDate)) . '\' AND StatDate <= \'' . date('Y-m-d', strtotime($inEndDate)) . '\' AND ppc_keywords.KeywordID = ' . $intInBidID . ' GROUP BY KeywordID) AS KeywordStats ON BidKeywordID = KeywordStats.KeywordID
					WHERE (keyword_tracker_clicks.UserID = ' . $intInUserID . ' AND keyword_tracker_clicks.BidKeywordID = ' . $intInBidID . ') ';
		$strSQL .= $strWhere;
		$strSQL .= ' GROUP BY RawKeywordID, RawKeyword';

		$this->Select($strSQL);
	}
	
/*	function GetAdGroupStats($intInUserID, $inStartDate, $inEndDate) {
		if (!is_numeric($intInUserID)) {
			return false;
		}
		
		if (!empty($inStartDate)) {
			$strWhere = 'ClickDate >= \'' . date('Y-m-d', strtotime($inStartDate)) . '\'';
			
			if (!empty($inEndDate)) {
				$strWhere .= ' AND ClickDate <= \'' . date('Y-m-d', strtotime($inEndDate)) . '\'';
			}
			
			if (strlen($strWhere) > 1) {
				$strWhere = ' AND (' . $strWhere . ') ';
			}
		}
		
		$strSQL = 'SELECT ppc_adgroups.Name AS AdGroupName, COUNT(keyword_tracker_keywords.ID) AS KeywordCount,
						SUM(ADPALACE_USER_AFF_NETWORK_SUBID.Clicks) AS KeywordClicks, SUM(ADPALACE_USER_AFF_NETWORK_SUBID.Conversions) AS KeywordConversions, SUM(ADPALACE_USER_AFF_NETWORK_SUBID.Revenue) AS KeywordRevenue,
						SUM(KeywordCost) AS AdGroupCost, AVG(KeywordCPC) AS AdGroupCPC
					FROM (((keyword_tracker_clicks LEFT JOIN keyword_tracker_keywords ON keyword_tracker_clicks.BidKeywordID = keyword_tracker_keywords.ID)
					LEFT JOIN ADPALACE_USER_AFF_NETWORK_SUBID ON keyword_tracker_clicks.SubID = ADPALACE_USER_AFF_NETWORK_SUBID.SUB_ID)
					LEFT JOIN ppc_keywords ON keyword_tracker_clicks.BidKeywordID = ppc_keywords.KeywordID)
						LEFT JOIN (SELECT ppc_keywords.KeywordID, SUM(Cost) AS KeywordCost, AVG(CPC) AS KeywordCPC FROM ppc_keywords_stats LEFT JOIN ppc_keywords ON ppc_keywords_stats.KeywordID = ppc_keywords.ID WHERE StatDate >= \'' . date('Y-m-d', strtotime($inStartDate)) . '\' AND StatDate <= \'' . date('Y-m-d', strtotime($inEndDate)) . '\' GROUP BY KeywordID) AS KeywordStats ON BidKeywordID = KeywordStats.KeywordID
					RIGHT JOIN ppc_adgroups ON ppc_keywords.AdGroupID = ppc_adgroups.ID
					WHERE (keyword_tracker_clicks.UserID = ' . $intInUserID . ') ';
		$strSQL .= $strWhere;
		$strSQL .= ' GROUP BY AdGroupName';

		$this->Select($strSQL);
	}
*/	
/*	function GetCampaignStats($intInUserID, $inStartDate, $inEndDate) {
		if (!is_numeric($intInUserID)) {
			return false;
		}
		
		if (!empty($inStartDate)) {
			$strWhere = 'ClickDate >= \'' . date('Y-m-d', strtotime($inStartDate)) . '\'';
			
			if (!empty($inEndDate)) {
				$strWhere .= ' AND ClickDate <= \'' . date('Y-m-d', strtotime($inEndDate)) . '\'';
			}
			
			if (strlen($strWhere) > 1) {
				$strWhere = ' AND (' . $strWhere . ') ';
			}
		}
		
		$strSQL = 'SELECT ppc_campaigns.Name AS CampaignName, ppc_campaigns.ProviderType, ppc_campaigns.AccountID, COUNT(keyword_tracker_keywords.ID) AS KeywordCount,
						SUM(ADPALACE_USER_AFF_NETWORK_SUBID.Clicks) AS KeywordClicks, SUM(ADPALACE_USER_AFF_NETWORK_SUBID.Conversions) AS KeywordConversions, SUM(ADPALACE_USER_AFF_NETWORK_SUBID.Revenue) AS KeywordRevenue
					FROM ((((keyword_tracker_clicks LEFT JOIN keyword_tracker_keywords ON keyword_tracker_clicks.BidKeywordID = keyword_tracker_keywords.ID)
					LEFT JOIN ADPALACE_USER_AFF_NETWORK_SUBID ON keyword_tracker_clicks.SubID = ADPALACE_USER_AFF_NETWORK_SUBID.SUB_ID)
					LEFT JOIN ppc_keywords ON keyword_tracker_clicks.BidKeywordID = ppc_keywords.KeywordID)
					LEFT JOIN ppc_adgroups ON ppc_keywords.AdGroupID = ppc_adgroups.ID)
					RIGHT JOIN ppc_campaigns ON ppc_adgroups.CampaignID = ppc_campaigns.ID
					WHERE (keyword_tracker_clicks.UserID = ' . $intInUserID . ') ';
		$strSQL .= $strWhere;
		$strSQL .= ' GROUP BY CampaignName, ProviderType, AccountID';

		$this->Select($strSQL);
	}
*/	
	function GetAdGroupStats($intInUserID, $inStartDate, $inEndDate) {
		if (!is_numeric($intInUserID)) {
			return false;
		}
		
		if (!empty($inStartDate)) {
			$strWhere = 'ClickDate >= \'' . date('Y-m-d', strtotime($inStartDate)) . '\'';
			
			if (!empty($inEndDate)) {
				$strWhere .= ' AND ClickDate <= \'' . date('Y-m-d', strtotime($inEndDate)) . '\'';
			}
			
			if (strlen($strWhere) > 1) {
				$strWhere = ' AND (' . $strWhere . ') ';
			}
		}
		$strSQL = 'SELECT ppc_adgroups.ID, ppc_adgroups.Name, SUM(clicks) AS KeywordClicks, SUM(conversions) AS KeywordConversions , SUM(revenue) AS NetRevenue
			FROM ((keyword_tracker_clicks LEFT JOIN ADPALACE_USER_AFF_NETWORK_SUBID ON keyword_tracker_clicks.subid = ADPALACE_USER_AFF_NETWORK_SUBID.sub_id)
			LEFT JOIN ppc_keywords ON keyword_tracker_clicks.bidkeywordid = ppc_keywords.keywordid)
			LEFT JOIN ppc_adgroups ON ppc_keywords.adgroupid = ppc_adgroups.id
			WHERE (keyword_tracker_clicks.UserID = ' . $intInUserID . ')';
		$strSQL .= $strWhere;
		$strSQL .= 'GROUP BY ppc_adgroups.ID, ppc_adgroups.Name';
		$this->Select($strSQL);
	}
	
	function GetCampaignStats($intInUserID, $inStartDate, $inEndDate) {
		if (!is_numeric($intInUserID)) {
			return false;
		}
		
		if (!empty($inStartDate)) {
			$strWhere = 'ClickDate >= \'' . date('Y-m-d', strtotime($inStartDate)) . '\'';
			
			if (!empty($inEndDate)) {
				$strWhere .= ' AND ClickDate <= \'' . date('Y-m-d', strtotime($inEndDate)) . '\'';
			}
			
			if (strlen($strWhere) > 1) {
				$strWhere = ' AND (' . $strWhere . ') ';
			}
		}
		$strSQL = 'SELECT ppc_campaigns.ID, ppc_campaigns.Name, COUNT(DISTINCT keyword_tracker_clicks.ID) AS KeywordCount, SUM(clicks) as KeywordClicks, SUM(conversions) AS KeywordConversions , SUM(revenue) AS KeywordRevenue
					FROM (((keyword_tracker_clicks LEFT JOIN ADPALACE_USER_AFF_NETWORK_SUBID ON keyword_tracker_clicks.subid = ADPALACE_USER_AFF_NETWORK_SUBID.sub_id)
					LEFT JOIN ppc_keywords ON keyword_tracker_clicks.bidkeywordid = ppc_keywords.keywordid)
					LEFT JOIN ppc_adgroups ON ppc_keywords.adgroupid = ppc_adgroups.id)
					LEFT JOIN ppc_campaigns ON ppc_adgroups.CampaignID = ppc_campaigns.ID
					WHERE (keyword_tracker_clicks.UserID = ' . $intInUserID . ') ';
		$strSQL .= $strWhere;
		$strSQL .= 'GROUP BY id, name';
		$this->Select($strSQL);
	}
	
	function SubIDExists($strInSubID) {
		$strSQL = 'SELECT SubID FROM keyword_tracker_clicks WHERE (SubID = \'' . $this->FixString($strInSubID) . '\')';
		$this->Select($strSQL);
	}

}

?>