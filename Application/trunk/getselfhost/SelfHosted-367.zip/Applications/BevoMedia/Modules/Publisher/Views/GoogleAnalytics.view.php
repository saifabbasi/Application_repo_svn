<img src='/Themes/<?php print $this->PageHelper->Application; ?>/img/analytics.jpg'>

<br/><br/>

<table align='center'>
<tbody><tr>
	<td>
		<a href="/BevoMedia/Publisher/GoogleAnalyticsAPI.html"><img src="/Themes/<?php print $this->PageHelper->Application; ?>/img/icon-installvia-api.jpg" style="border: 0px none ;"></a>
	</td>
	<td style="border-left: 1px solid rgb(239, 239, 239);">&nbsp;</td>
	<?php /*?>
	<td>
		<a href="/BevoMedia/Publisher/GoogleAdwordsAPI.html"><img src="/Themes/<?php print $this->PageHelper->Application; ?>/img/icon-installvia-xml.jpg" style="border: 0px none ;"></a>
	</td>
	<td style="border-left: 1px solid rgb(239, 239, 239);">&nbsp;</td>

	<td>
		<a href="/publisher-mynetworks.php?google_adwords=2&amp;manual_upload=1"><img src="/Themes/<?php print $this->PageHelper->Application; ?>/img/icon-upload-daybyday.jpg" style="border: 0px none ;"></a>
	</td>
	<?php */?>
</tr>
<tr>
	<td>
		<a href="/BevoMedia/Publisher/GoogleAnalyticsAPI.html"><img src="/Themes/<?php print $this->PageHelper->Application; ?>/img/button-clickhere.jpg" style="border: 0px none ;"></a>
	</td>
	<?php /*?>
	<td style="border-left: 1px solid rgb(239, 239, 239);">&nbsp;</td>

	<td>
		<a href="/publisher-mynetworks.php?google_adwords=2"><img src="/Themes/<?php print $this->PageHelper->Application; ?>/img/button-clickhere.jpg" style="border: 0px none ;"></a>
	</td>
	<td style="border-left: 1px solid rgb(239, 239, 239);">&nbsp;</td>
	<td>
		<a href="/publisher-mynetworks.php?google_adwords=2&amp;manual_upload=1"><img src="/Themes/<?php print $this->PageHelper->Application; ?>/img/button-manualupload.jpg" style="border: 0px none ;"></a>
	</td>
	<?php */?>
</tr>
</tbody>
</table>

<br/><br/>

What's the difference between the 3 methods?

<br/>