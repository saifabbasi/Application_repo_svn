<div id="pageinfo" class="sub">
	<h2>Registration Successful!</h2>
</div>

<div class="clear"></div>


<br/><br/>
<div class='content'>
<a href='<?=$this->{'System/BaseURL'};?><?=$this->{'Application/Theme'};?>/User/Register.html'>
<div style='
		width: 80px; height: 30px; float: left; z-index: 1100; color: #FFFFFF;
		background-image: url(<?=$this->{'System/BaseURL'};?>Themes/<?=$this->{'Application/Theme'};?>/img/Signup_05.gif);
		position: relative; left: 20px; margin-right: 5px;
		line-height: 30px; text-align: center;'>
	Step 1
</div>
</a>


<div style='
		width: 80px; height: 30px;  float: left; color: #0077B3;
		background-image: url(<?=$this->{'System/BaseURL'};?>Themes/<?=$this->{'Application/Theme'};?>/img/Signup_03.gif);
		position: relative; left: 20px; z-index: 1000;
		line-height: 30px; text-align: center;'>
	Step 2
</div>
<br class='clearBoth'/>
<div
	style="width: 624px; background-color: #F2FCFF; border-left: solid 2px #00B4E1; border-right: solid 2px #00B4E1;">

	<img src='<?=$this->{'System/BaseURL'};?>Themes/<?=$this->{'Application/Theme'};?>/img/Signup_08.gif' style='position: relative; left: -2px; top:-2px; z-index:900;'/>
		
	<div style='margin-left: 5px;'>

		<br/>
		Your account was created successfully!
		<br/>
		<br/>
	</div>
	
	<img src='/Themes/BevoMedia/img/Signup_18.gif' style='position: relative; left: -2px;'/>
</div>

</div>