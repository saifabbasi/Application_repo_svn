<div id="pagemenu"></div>

<?php echo $this->PageDesc->ShowDesc($this->PageHelper); ?>
	
<div class="pagecontent">
	<a class="tbtn floatright" href="BevoUpgrade.html?force=true">Force an upgrade / clean install</a> [Your user data will be preserved]
	<p>BevoMedia Selfhost Version: <?= $this->PH->thisVersion() ? $this->PH->thisVersion() : 'Unknown' ?>
	<div class="clear"></div>

	<form method='post'>
		<table width="100%" cellspacing="0" cellpadding="3" border="0" class="btable adminPublisherTable">
			<tr class="table_header">
				<td class="hhl">&nbsp;</td>
				<td style="text-align:center;">ID</td>
				<td style="text-align:left;">Username</td>
				<td style="text-align:left;">BevoLive account</td>
				<td style="text-align:left;">Enabled</td>
				<td colspan="2" style="text-align:center;">Actions</td>
				<td class="hhr">&nbsp;</td>
			</tr>

			<?php foreach($this->AllUsers as $Key=>$User):
				$live = $this->db->fetchRow('SELECT * FROM bevomedia_dotcom_accounts WHERE user__id='.$User->id); ?>
				
				<?php if($User->deleted): ?>
					<tr class='<?php echo($User->deleted)?'deletedPublisher':''?>'>
						<td class="border">&nbsp;</td>
						<td style="text-align:left;"><?php print $User->id; ?></td>
						<td class='nameCell'><?php print $User->email; ?></td>
						<td></td>
						<td colspan="1" style="text-align:center;">DELETED</td>
						<td></td>
						<td>
							<a class='blackText' href='RestoreUser.html?id=<?php print $User->id; ?>'>Restore</a>
						</td>
						<td class="tail">&nbsp;</td>
					</tr>
					
				<?php else: ?>
					<tr class='<?php echo($Key%2)?'lightBlueRow':'darkBlueRow'?>'>
						<td class="border" style="padding: 0px;">&nbsp;</td>
						<td style="text-align:center;"><?php print $User->id; ?></td>
						<td class='nameCell'><?php print $User->email; ?></td>
						<td>
						<?
							if(!$this->PH->disabled)
							{
								if($live)
								{
									if($live->enabled)
									{
										echo 'Enabled: ' . $live->username . ' ';
										echo '<a href="DisassociateLiveAccount.html?id='.$live->id.'">';
										echo '[disassociate]';
										echo '</a>';
									}
									else
									{
										echo 'Invalid Username/Password ';
										echo '<a href="DisassociateLiveAccount.html?id='.$live->id.'">';
										echo '[fix it]';
										echo '</a>';
									}
								}
								else
								{
									echo 'None ';
									echo '<a rel="shadowbox;width=480;height=250;player=iframe" href="AddLiveAccount.html?id='.$User->id.'">';
									echo '[add one]';
									echo '</a>';
								}
							} else {
								echo '<b>NoPhoneHome=true</b> set in config.ini';
							}
						?>
						</td>
						<td><?php print ($User->enabled)?'Enabled':'Disabled'; ?></td>
						<td>
							<?php if($User->enabled):?>
								<a href='DisableUser.html?id=<?php print $User->id; ?>'>Disable</a>
							<?php else:?>
								<a href='EnableUser.html?id=<?php print $User->id; ?>'>Enable</a>
							<?php endif?>
						</td>
						<td>
							<a href='DeleteUser.html?id=<?php print $User->id; ?>'>
								Delete
							</a>
						</td>
						<td class="tail">&nbsp;</td>
					</tr>
				<?php endif?>
			<?php endforeach?>

			<?php if(!sizeOf($this->AllUsers)):?>
				<tr>
					<td class="border">&nbsp;</td>
					<td style="text-align:center;" colspan="6">
						<i>No Results</i>
					</td>
					<td class="tail">&nbsp;</td>
				</tr>
			<?php endif?>
		</table>
	
		<a class="tbtn floatright" rel="shadowbox;width=480;height=250;player=iframe" href="AddUser.html">Add a user</a>
		<div class="clear"></div>
	</form>

	<br /><br />

	<?php if($this->PH->disabled) {?>
		<p>You have <code>NoPhoneHome = true</code> set in your <strong>config.ini</strong> file,</b> probably because you opted out of all our BevoMedia.com services during installation. If you've changed your mind, and want to enable services from BevoMedia.com like new version notifications, automatic network stats updates and the PPC campaign editor, just edit the file <strong>config.ini</strong> (located on your server in the folder you installed Bevo in) and remove the fourth line, <code>NoPhoneHome = true</code>.</p>
		
		<p>We created this configuration setting so that users concerned about privacy would have guaranteed peace of mind in the absolute privacy of their data. When the <code>NoPhoneHome</code> setting is <code>true</code>, <strong>no data at all</strong> is sent to BevoMedia.com. Ever. You won't see new networks or new offers and you won't be automatically notified of new versions of BevoMedia software.</p>
	<?php } ?>
</div><!--close pagecontent-->